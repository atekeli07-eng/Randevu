'use client';
import { createClient } from '@supabase/supabase-js';
import { useState } from 'react';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export default function SignUp() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [msg, setMsg] = useState('');

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const { error } = await supabase.auth.signUp({
      email, password,
      options: { data: { full_name: fullName } }
    });
    setMsg(error ? error.message : 'Kayıt başarılı, e-postanı kontrol et veya giriş yap.');
  };

  return (
    <div>
      <h1>Kayıt Ol</h1>
      <form onSubmit={onSubmit}>
        <input placeholder="Ad Soyad" value={fullName} onChange={e=>setFullName(e.target.value)} required />
        <input placeholder="E-posta" type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
        <input placeholder="Şifre" type="password" value={password} onChange={e=>setPassword(e.target.value)} required />
        <button type="submit">Kayıt Ol</button>
      </form>
      <p>{msg}</p>
    </div>
  );
}
