'use client';
import { createClient } from '@supabase/supabase-js';
import { useState } from 'react';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export default function SignIn() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState('');

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setMsg(error ? error.message : 'Giriş başarılı, ana sayfaya dönün.');
  };

  return (
    <div>
      <h1>Giriş</h1>
      <form onSubmit={onSubmit}>
        <input placeholder="E-posta" type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
        <input placeholder="Şifre" type="password" value={password} onChange={e=>setPassword(e.target.value)} required />
        <button type="submit">Giriş Yap</button>
      </form>
      <p>{msg}</p>
    </div>
  );
}
