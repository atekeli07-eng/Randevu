export const metadata = {
  title: "Berber Randevu",
  description: "EsnafMuhabbeti - Randevu Sistemi"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="tr">
      <body style={{ fontFamily: "ui-sans-serif, system-ui", margin: 0 }}>
        <header style={{ display: "flex", justifyContent: "space-between", padding: "12px 16px", borderBottom: "1px solid #eee" }}>
          <a href="/">Berber Randevu</a>
          <nav style={{ display: "flex", gap: 12 }}>
            <a href="/me">Randevularım</a>
            <a href="/auth/sign-in">Giriş</a>
            <a href="/auth/sign-up">Kayıt Ol</a>
          </nav>
        </header>
        <main style={{ maxWidth: 880, margin: "24px auto", padding: "0 16px" }}>{children}</main>
        <footer style={{ padding: "24px 16px", color: "#777", borderTop: "1px solid #eee" }}>
          © {new Date().getFullYear()} EsnafMuhabbeti
        </footer>
      </body>
    </html>
  );
}
