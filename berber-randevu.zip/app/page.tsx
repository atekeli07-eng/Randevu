import { createClient } from '@/lib/supabase';

async function getData() {
  const supabase = createClient();
  const { data: services } = await supabase.from('services').select('*').order('name');
  const { data: staff } = await supabase.from('staff').select('*').eq('is_active', true).order('display_name');
  return { services: services ?? [], staff: staff ?? [] };
}

export default async function Home() {
  const { services, staff } = await getData();

  return (
    <div>
      <h1>Randevu Al</h1>
      <form id="wizard" onSubmit={(e) => e.preventDefault()}>
        <label>Servis</label>
        <select id="service">
          {services.map((s:any) => <option key={s.id} value={s.id}>{s.name} – {Number(s.price).toFixed(2)}₺ / {s.duration_min}dk</option>)}
        </select>

        <label style={{display:'block', marginTop:12}}>Personel</label>
        <select id="staff">
          {staff.map((st:any) => <option key={st.id} value={st.id}>{st.display_name}</option>)}
        </select>

        <label style={{display:'block', marginTop:12}}>Gün</label>
        <input id="day" type="date" />

        <button style={{display:'block', marginTop:12}} onClick={async () => {
          const service = (document.getElementById('service') as HTMLSelectElement).value;
          const staff = (document.getElementById('staff') as HTMLSelectElement).value;
          const day = (document.getElementById('day') as HTMLInputElement).value;
          const res = await fetch(`/api/available?service=${service}&staff=${staff}&day=${day}`);
          const json = await res.json();
          const box = document.getElementById('slots');
          if (box) {
            box.innerHTML = '';
            (json.slots || []).forEach((sl: any) => {
              const btn = document.createElement('button');
              btn.textContent = new Date(sl.start_ts).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
              btn.style.margin = '4px';
              btn.onclick = async () => {
                const ok = confirm(`Bu saat için randevu alınsın mı? ${new Date(sl.start_ts).toLocaleString()}`);
                if (!ok) return;
                const resp = await fetch('/api/bookings', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    staff_id: staff,
                    service_id: service,
                    start_ts: sl.start_ts,
                    end_ts: sl.end_ts
                  })
                });
                const j = await resp.json();
                alert(j.ok ? 'Randevu alındı' : ('Hata: ' + j.error));
              };
              box.appendChild(btn);
            });
          }
        }}>Uygun Saatleri Göster</button>
      </form>

      <div id="slots" style={{ marginTop: 16 }}></div>
    </div>
  );
}
