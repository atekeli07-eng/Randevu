import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase';

export async function POST(req: Request) {
  const body = await req.json();
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Giriş gerekli' }, { status: 401 });

  const payload = {
    user_id: user.id,
    staff_id: body.staff_id,
    service_id: body.service_id,
    start_ts: body.start_ts,
    end_ts: body.end_ts,
    status: 'confirmed'
  };

  const { error } = await supabase.from('bookings').insert(payload);
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ ok: true });
}
