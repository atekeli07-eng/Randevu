import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase';

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const staff = searchParams.get('staff');
  const service = searchParams.get('service');
  const day = searchParams.get('day');
  const step = Number(searchParams.get('step') ?? 30);

  if (!staff || !service || !day) {
    return NextResponse.json({ error: 'Eksik parametre' }, { status: 400 });
  }

  const supabase = createClient();
  const { data, error } = await supabase.rpc('available_slots', {
    _staff: staff, _service: service, _day: day, _step_min: step
  });

  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ slots: data });
}
