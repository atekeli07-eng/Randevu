import { createClient } from '@/lib/supabase';

export default async function Me() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return <div><p>Randevularınızı görmek için lütfen <a href="/auth/sign-in">giriş yapın</a>.</p></div>
  }

  const { data: bookings } = await supabase
    .from('bookings')
    .select('id, start_ts, end_ts, status, services(name), staff(display_name)')
    .order('start_ts', { ascending: false });

  return (
    <div>
      <h1>Randevularım</h1>
      <ul>
        {bookings?.map((b:any) => (
          <li key={b.id} style={{ margin: '8px 0' }}>
            <strong>{new Date(b.start_ts).toLocaleString()}</strong>
            {' – '}{b.services?.name} {' – '}{b.staff?.display_name} {' – '} {b.status}
            {b.status === 'confirmed' && (
              <form action={`/api/bookings/${b.id}/cancel`} method="post" style={{ display: 'inline-block', marginLeft: 8 }}>
                <button type="submit">İptal Et</button>
              </form>
            )}
          </li>
        ))}
        {!bookings?.length && <li>Henüz randevunuz yok.</li>}
      </ul>
    </div>
  );
}
