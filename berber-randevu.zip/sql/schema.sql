-- Enable extension
create extension if not exists btree_gist;

-- Profiles
create table if not exists public.profiles (
  id uuid primary key references auth.users on delete cascade,
  full_name text,
  phone text,
  created_at timestamptz default now()
);

-- Staff
create table if not exists public.staff (
  id uuid primary key default gen_random_uuid(),
  display_name text not null,
  is_active boolean not null default true
);

-- Services
create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  duration_min int not null check (duration_min in (15,20,30,45,60,90,120)),
  price decimal(10,2) not null default 0
);

-- Working hours
create table if not exists public.working_hours (
  id uuid primary key default gen_random_uuid(),
  staff_id uuid not null references public.staff(id) on delete cascade,
  weekday int not null check (weekday between 0 and 6), -- 0=Sunday
  start_time time not null,
  end_time time not null,
  unique (staff_id, weekday, start_time, end_time)
);

-- Blackouts
create table if not exists public.blackouts (
  id uuid primary key default gen_random_uuid(),
  staff_id uuid references public.staff(id) on delete cascade,
  start_ts timestamptz not null,
  end_ts timestamptz not null,
  reason text
);

-- Bookings
create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  staff_id uuid not null references public.staff(id) on delete restrict,
  service_id uuid not null references public.services(id) on delete restrict,
  start_ts timestamptz not null,
  end_ts timestamptz not null,
  status text not null default 'confirmed' check (status in ('confirmed','cancelled')),
  created_at timestamptz not null default now()
);

-- Overlap prevent per staff
alter table public.bookings
  drop constraint if exists no_overlap_per_staff;

alter table public.bookings
  add constraint no_overlap_per_staff
  exclude using gist (
    staff_id with =,
    tstzrange(start_ts, end_ts, '[)') with &&
  )
  where (status = 'confirmed');

-- RLS
alter table public.profiles enable row level security;
alter table public.bookings enable row level security;
alter table public.staff enable row level security;
alter table public.services enable row level security;

-- Policies
drop policy if exists "users view own profile" on public.profiles;
create policy "users view own profile" on public.profiles
for select using (auth.uid() = id);

drop policy if exists "users update own profile" on public.profiles;
create policy "users update own profile" on public.profiles
for update using (auth.uid() = id);

drop policy if exists "public read services" on public.services;
create policy "public read services" on public.services
for select using (true);

drop policy if exists "public read staff" on public.staff;
create policy "public read staff" on public.staff
for select using (true);

drop policy if exists "users select own bookings" on public.bookings;
create policy "users select own bookings" on public.bookings
for select using (auth.uid() = user_id);

drop policy if exists "users insert own bookings" on public.bookings;
create policy "users insert own bookings" on public.bookings
for insert with check (auth.uid() = user_id);

drop policy if exists "users cancel own bookings" on public.bookings;
create policy "users cancel own bookings" on public.bookings
for update using (auth.uid() = user_id);

-- Trigger to sync profiles on new user
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''))
  on conflict (id) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- RPC: available_slots
create or replace function public.available_slots(_staff uuid, _service uuid, _day date, _step_min int)
returns table (start_ts timestamptz, end_ts timestamptz) language sql stable as $$
  with svc as (
    select duration_min from public.services where id=_service
  ),
  wh as (
    select start_time, end_time
    from public.working_hours
    where staff_id=_staff and weekday=extract(dow from _day)
  ),
  gen as (
    select
      ts as start_ts,
      ts + ((select duration_min from svc) || ' minutes')::interval as end_ts
    from wh, lateral
      generate_series(
        (_day + wh.start_time)::timestamptz,
        (_day + wh.end_time)::timestamptz - ((select duration_min from svc) || ' minutes')::interval,
        make_interval(mins => _step_min)
      ) as ts
  )
  select g.start_ts, g.end_ts
  from gen g
  where not exists (
    select 1 from public.blackouts b
    where (g.start_ts, g.end_ts) overlaps (b.start_ts, b.end_ts)
      and (b.staff_id is null or b.staff_id = _staff)
  )
  and not exists (
    select 1 from public.bookings bk
    where bk.staff_id=_staff and bk.status='confirmed'
      and (g.start_ts, g.end_ts) overlaps (bk.start_ts, bk.end_ts)
  )
  order by g.start_ts;
$$;
