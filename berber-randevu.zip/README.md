# Berber Randevu – Next.js + Supabase İskeleti

> Kullanıcı kayıt/giriş, servis & personel seç, uygun saatleri gör, randevu al/iptal et, "Randevularım" paneli.

## Hızlı Kurulum
1. `cp .env.example .env` yap ve Supabase URL/Anon Key değerlerini doldur.
2. `npm install`
3. **Supabase SQL** bölümündeki komutları Supabase SQL Editor'a yapıştır.
4. `npm run dev`
5. Tarayıcı: http://localhost:3000

## Supabase SQL (Şema + RLS + RPC)
Aşağıdaki dosyayı açıp tamamını kopyalayıp çalıştır:
- `sql/schema.sql`

## Notlar
- Slot adımı 30 dk. Servis sürelerine göre (30/45/60/90/120) ardışık uygunluk kontrol edilir.
- Çakışma: DB `EXCLUDE` constraint ile engellenir.
- İptal: Kullanıcı sadece kendi randevusunu iptal eder.
- Yönetim: `services`, `staff`, `working_hours` tablolarını Supabase arayüzünden doldur.

